package com.example.firstapps;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {
    Button btnSubmit;
    EditText editUsername,editPassword,editAngka1,editAngka2;
    TextView text,isiUsername,textHasil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editAngka1 = findViewById(R.id.editAngka1);
        editAngka2 = findViewById(R.id.editAngka2);
        textHasil = findViewById(R.id.textHasil);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        isiUsername = findViewById(R.id.isiUsername);
        text= findViewById(R.id.textView);


        btnSubmit = findViewById(R.id.btnSubmit);

    }

    public void Submit(View view) {
        String Username = editUsername.getText().toString();
        String Password = editPassword.getText().toString();
        Toast.makeText(getApplicationContext(),"berhasil",Toast.LENGTH_SHORT).show();
        isiUsername.setText(editUsername.getText());
    }

    public void penambahan(View view) {
        int angka1 = Integer.parseInt(editAngka1.getText().toString());
        int angka2 = Integer.parseInt(editAngka2.getText().toString());
        textHasil.setText(String.valueOf(angka1+angka2));
    }
}